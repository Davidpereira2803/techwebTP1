#rq!!: à ce stade j'ai juste changer les appelations 
from fastapi import APIRouter, HTTPException, status
from fastapi.responses import JSONResponse
from pydantic import ValidationError
from uuid import uuid4

from app.schemas import Book
import app.services.book as service

router = APIRouter(prefix="/books", tags=["books"])

@router.get('/')
def get_all_books():
    books = service.get_all_books()
    return JSONResponse(
        content=[book.dict() for book in books],  
        status_code=200,
    )

@router.get('/{book_id}')
def get_book(book_id: str):
    book = service.get_book_by_id(book_id)
    if book is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No book found with this ID.",
        )
    return JSONResponse(book.dict())  

@router.post('/')
def create_new_book(new_book: Book):  
    new_book_data = new_book.dict()  
    new_book_data["id"] = str(uuid4())  
    try:
        created_book = Book(**new_book_data)  
    except ValidationError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid book data: {e}",  
        )
    service.save_book(created_book)
    return JSONResponse(created_book.dict())