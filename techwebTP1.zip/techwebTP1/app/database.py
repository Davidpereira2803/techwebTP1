
database = {
    "books": [
        {
            "name": "Structure and Interpretation of Computer Programs",
            "ISBN": '978-0262510875',
            "author": "Harold Abelson, Gerald Jay Sussman and Julie Sussman",
            "editor": 'MIT Press',
        },
        {
            "name": "Introduction to Algorithms",
            "ISBN": '978-0262510875',
            "author": "Thomas H. Cormen, Charles E. Leiserson, Ronald L. Rivest, and Clifford Stein",
            "editor": 'MIT Press',
        },
        {
            "name": "Design Patterns: Elements of Reusable Object-Oriented Software",
            "ISBN": '978-0201633610',
            "author": "Erich Gamma, Richard Helm, Ralph Johnson, et John Vlissides",
            "editor": 'Addison-Wesley Professional',
        },
    ]
}