from app.structure import book
from app.database import database


def save_book(new_book: book) -> book:
    database["books"].append(new_book)
    return new_book


def get_all_books() -> list[book]:
    books_data = database["book"]
    book = [book.model_validate(data) for data in books_data]
    return book

def validate_book(book_ISBN : str):
    book_validated=[
        book for books in database["books"]
        if book["ISBN"] == book_ISBN
    ]
    if(book_validated) < 1 or book_validated == " ":
        return False
    book_validated = book.model_validate(validate_book[0])
    return validate_book
def delete_book( book_ISBN: str):
    for book in database["books"]:
        if book["ISBN"] == book_ISBN:
            database["books"].remove(book)
            return True
    return False
def update_book(book_ISBN: str, new_data: dict):
    for book in database["books"]:
        if book["ISBN"]== book_ISBN:
            book.update(new_data)
            update_book = book.model_validate(book)
            if update_book:
                return update_book
            else:
                book.update(new_data)
            return None
    return None