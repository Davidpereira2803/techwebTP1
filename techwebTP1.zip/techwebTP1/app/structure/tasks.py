from pydantic import BaseModel, Field


class Book(BaseModel):
    name: str =  Field(min_lenght=4)
    ISBN: str = Field(lenght= 13)
    author: str
    editor: str